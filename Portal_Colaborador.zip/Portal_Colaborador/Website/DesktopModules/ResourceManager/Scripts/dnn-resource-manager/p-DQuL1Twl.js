const o=()=>{};export{o as g};
//# sourceMappingURL=p-DQuL1Twl.js.map