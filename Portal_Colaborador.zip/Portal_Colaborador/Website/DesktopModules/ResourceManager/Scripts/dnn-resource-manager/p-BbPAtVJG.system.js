System.register([],(function(t){"use strict";return{execute:function(){var n=t("g",(function(){}))}}}));
//# sourceMappingURL=p-BbPAtVJG.system.js.map